<?php
    $hostname_eva = "localhost";
    $database_eva = "steazhex_allonfasaha";
    $username_eva = "steazhex_allonfasaha";
    $password_eva = "allonfasaha1234@";
    $allo = mysqli_connect($hostname_eva, $username_eva, $password_eva, $database_eva) or trigger_error(mysql_error(),E_USER_ERROR);
?>
